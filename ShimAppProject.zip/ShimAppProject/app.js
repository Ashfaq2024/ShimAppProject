let totalWeight = 0;
let totalCount = 0;

function calculateTotal() {
    let weight = document.getElementById("weight").value;
    let count = document.getElementById("count").value;

    // Clear any previous error messages
    document.getElementById("errorMessage").textContent = '';

    // Validate input
    if (isNaN(weight) || isNaN(count) || weight === '' || count === '') {
        document.getElementById("errorMessage").textContent = 'Please enter valid numbers for weight and count.';
        return; // Exit if invalid input
    }

    // Calculate total weight
    totalWeight = parseFloat(weight) * parseInt(count);
    totalCount = parseInt(count);

    // Display the total weight and count
    document.getElementById("total").textContent = "Total Weight: " + totalWeight + " kg, Count: " + totalCount;
}

function printTotals() {
    alert("Total Weight: " + totalWeight + " kg, Count: " + totalCount);

    // Clear totals after printing
    totalWeight = 0;
    totalCount = 0;
    document.getElementById("weight").value = '';
    document.getElementById("count").value = '';
    document.getElementById("total").textContent = '';
}

function showHelp() {
    alert("To use this app:\n\n1. Enter the weight and count of shims.\n2. Click 'Calculate' to see the total weight and count.\n3. Click 'Print Totals' to view and clear the totals.");
}
